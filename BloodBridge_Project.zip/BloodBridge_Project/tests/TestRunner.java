import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.List;

/**
 * TestRunner.java - simple tests without any framework.
 * Run it, and it prints PASS or FAIL for each test case (T1 ... T12 match the report).
 */
public class TestRunner {

    private static int passed = 0;
    private static int failed = 0;

    private static void check(String id, String description, boolean condition) {
        if (condition) { passed++; System.out.println("PASS  " + id + "  " + description); }
        else           { failed++; System.out.println("FAIL  " + id + "  " + description); }
    }

    /** Returns true if creating this donor throws IllegalArgumentException. */
    private static boolean rejected(String name, String group, String city, String area, String phone) {
        try {
            new Donor(name, group, city, area, phone, true);
            return false;
        } catch (IllegalArgumentException e) {
            return true;
        }
    }

    /** Names of results, in order, as one string - makes order checks easy. */
    private static String names(List<MatchResult> list) {
        StringBuilder sb = new StringBuilder();
        for (MatchResult r : list) sb.append(r.getDonor().getName()).append(";");
        return sb.toString();
    }

    public static void main(String[] args) {
        BloodMatcher matcher = new BloodMatcher();

        // ---- T1: register a valid volunteer ----
        DonorManager m1 = new DonorManager();
        boolean added = m1.registerDonor(new Donor("Test Person", "B+", "Testville", "Central", "9111111111", true));
        check("T1", "Valid volunteer is registered", added && m1.getTotalCount() == 1);

        // ---- T2: invalid blood group ----
        check("T2", "Invalid blood group 'C+' is rejected", rejected("Test Person", "C+", "Testville", "Central", "9111111111"));
        check("T2b", "Lower-case 'ab+' is accepted and stored as 'AB+'",
                new Donor("Test Person", " ab+ ", "Testville", "Central", "9111111111", true).getBloodGroup().equals("AB+"));

        // ---- T3: blank required fields ----
        check("T3a", "Blank name rejected", rejected("   ", "A+", "Testville", "Central", "9111111111"));
        check("T3b", "Blank city rejected", rejected("Test Person", "A+", "", "Central", "9111111111"));
        check("T3c", "Blank area rejected", rejected("Test Person", "A+", "Testville", "  ", "9111111111"));
        check("T3d", "Null name rejected (no crash)", rejected(null, "A+", "Testville", "Central", "9111111111"));
        check("T3e", "Bad phone numbers rejected",
                rejected("Test Person", "A+", "Testville", "Central", "12345")
             && rejected("Test Person", "A+", "Testville", "Central", "abcdefghij")
             && rejected("Test Person", "A+", "Testville", "Central", "5123456789"));
        check("T3f", "Phone '+91 98765-43210' accepted",
                !rejected("Test Person", "A+", "Testville", "Central", "+91 98765-43210"));

        // ---- T4: invalid consent input (handled in Main as yes/no) -> checked by menu test script (see M3) ----

        // ---- Shared fictional data for search tests ----
        DonorManager manager = new DonorManager();
        manager.loadSampleData();
        List<Donor> all = manager.getAllDonors();

        // ---- T5: same area (recipient A+, Bengaluru / Indiranagar) ----
        List<MatchResult> r5 = matcher.findMatches(all, "A+", "Bengaluru", "Indiranagar");
        check("T5", "Same-area donors are Priority 1 and come first (Meera exact group, then Aarav)",
                r5.get(0).getDonor().getName().equals("Meera Nair") && r5.get(0).getPriority() == 1
             && r5.get(1).getDonor().getName().equals("Aarav Sharma") && r5.get(1).getPriority() == 1);

        // ---- T6: same city, other area ----
        check("T6", "Divya Menon (Jayanagar) is Priority 2 for a seeker in Indiranagar",
                names(r5).contains("Divya Menon") && priorityOf(r5, "Divya Menon") == 2);

        // ---- T7: other city ----
        check("T7", "Imran Khan (Mysuru) is Priority 3 and listed last",
                priorityOf(r5, "Imran Khan") == 3 && names(r5).endsWith("Imran Khan;"));
        check("T7b", "Complete order is Meera, Aarav, Divya, Imran", names(r5).equals("Meera Nair;Aarav Sharma;Divya Menon;Imran Khan;"));

        // ---- T8: non-consenting volunteer excluded ----
        check("T8", "Sneha Iyer (O+, no consent) is NOT in the results", !names(r5).contains("Sneha Iyer"));
        check("T8b", "Exactly 1 compatible volunteer reported as not consented", matcher.countCompatibleWithoutConsent(all, "A+") == 1);

        // ---- T9: no match ----
        DonorManager small = new DonorManager();
        small.registerDonor(new Donor("Only Donor", "A+", "Testville", "Central", "9222222222", true));
        check("T9", "No match for recipient O- when only an A+ donor exists",
                matcher.findMatches(small.getAllDonors(), "O-", "Testville", "Central").isEmpty());
        check("T9b", "Empty donor list gives empty result, no crash",
                matcher.findMatches(new DonorManager().getAllDonors(), "A+", "X", "Y").isEmpty());

        // ---- T10: invalid menu choice -> checked by menu test script (see M2) ----

        // ---- T11: compatibility direction ----
        check("T11a", "O- can donate to AB+", BloodMatcher.canDonateTo("O-", "AB+"));
        check("T11b", "AB+ can NOT donate to O- (wrong direction)", !BloodMatcher.canDonateTo("AB+", "O-"));
        check("T11c", "A+ can NOT donate to A-", !BloodMatcher.canDonateTo("A+", "A-"));
        check("T11d", "A- CAN donate to A+", BloodMatcher.canDonateTo("A-", "A+"));
        check("T11e", "B+ cannot donate to A+", !BloodMatcher.canDonateTo("B+", "A+"));
        check("T11f", "Recipient O- accepts only O-", BloodMatcher.getCompatibleDonorGroups("O-").equals(List.of("O-")));
        check("T11g", "Recipient AB+ accepts all 8 groups", BloodMatcher.getCompatibleDonorGroups("AB+").size() == 8);
        check("T11h", "All 64 donor/recipient pairs match the specification table", fullTableMatches());

        // ---- T12: privacy / encapsulation ----
        boolean allPrivate = true;
        for (Field f : Donor.class.getDeclaredFields()) {
            if (!Modifier.isPrivate(f.getModifiers()) && !Modifier.isStatic(f.getModifiers())) allPrivate = false;
            if (Modifier.isStatic(f.getModifiers()) && !Modifier.isPrivate(f.getModifiers())) allPrivate = false;
        }
        check("T12a", "Every field of Donor is private", allPrivate);

        Donor hidden = new Donor("Hidden Person", "A+", "Testville", "Central", "9333333333", false);
        check("T12b", "Phone of non-consenting donor is not returned", !hidden.getContactIfAllowed().contains("9333333333"));
        check("T12c", "toString() never contains the phone number", !hidden.toString().contains("9333333333"));
        Donor visible = new Donor("Visible Person", "A+", "Testville", "Central", "9444444444", true);
        check("T12d", "Phone of consenting donor is returned", visible.getContactIfAllowed().equals("9444444444"));
        hidden.updateConsent(true);
        check("T12e", "updateConsent(true) makes the number available", hidden.getContactIfAllowed().equals("9333333333"));
        boolean badUpdateRejected = false;
        try { hidden.updatePhone("123"); } catch (IllegalArgumentException e) { badUpdateRejected = true; }
        check("T12f", "updatePhone() rejects an invalid number and keeps the old one",
                badUpdateRejected && hidden.getContactIfAllowed().equals("9333333333"));
        boolean noGetPhone = true;
        for (java.lang.reflect.Method mth : Donor.class.getDeclaredMethods()) {
            if (mth.getName().equals("getPhone")) noGetPhone = false;
        }
        check("T12g", "Donor has no getPhone() method at all", noGetPhone);

        // ---- extra: duplicates and case/space-insensitive location ----
        DonorManager dm = new DonorManager();
        dm.registerDonor(new Donor("Dup One", "A+", "Testville", "Central", "9555555555", true));
        boolean second = dm.registerDonor(new Donor("Dup Two", "B+", "Testville", "Central", "+91 95555-55555", true));
        check("T13", "Duplicate phone number is rejected", !second && dm.getTotalCount() == 1);

        List<MatchResult> r14 = matcher.findMatches(all, "A+", "  BENGALURU ", "indiranagar   ");
        check("T14", "Location match ignores case and extra spaces", priorityOf(r14, "Meera Nair") == 1);

        List<Donor> copy = manager.getAllDonors();
        copy.clear();
        check("T15", "Clearing the copy returned by getAllDonors() does not affect the manager", manager.getTotalCount() == 7);

        System.out.println("\nResult: " + passed + " passed, " + failed + " failed.");
        if (failed > 0) System.exit(1);
    }

    private static int priorityOf(List<MatchResult> list, String name) {
        for (MatchResult r : list) if (r.getDonor().getName().equals(name)) return r.getPriority();
        return -1;
    }

    /** Independent copy of the specification table, compared against the code for all 64 pairs. */
    private static boolean fullTableMatches() {
        String[][] spec = {
            {"O-",  "O-"},
            {"O+",  "O-,O+"},
            {"A-",  "O-,A-"},
            {"A+",  "O-,O+,A-,A+"},
            {"B-",  "O-,B-"},
            {"B+",  "O-,O+,B-,B+"},
            {"AB-", "O-,A-,B-,AB-"},
            {"AB+", "A+,A-,B+,B-,AB+,AB-,O+,O-"}
        };
        for (String[] row : spec) {
            List<String> allowed = List.of(row[1].split(","));
            for (String donorGroup : BloodMatcher.getSupportedBloodGroups()) {
                if (BloodMatcher.canDonateTo(donorGroup, row[0]) != allowed.contains(donorGroup)) return false;
            }
        }
        return true;
    }
}
