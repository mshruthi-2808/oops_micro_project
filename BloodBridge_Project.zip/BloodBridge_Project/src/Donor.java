/**
 * Donor.java
 * ----------
 * Represents ONE volunteer donor.
 *
 * MAIN OOPS CONCEPT: ENCAPSULATION
 *  1. Every field is PRIVATE  -> outside code cannot read or change them directly (data hiding).
 *  2. The ONLY way to create a Donor is the constructor, which VALIDATES the data first,
 *     so an invalid Donor (blank name, wrong blood group, bad phone) can never exist.
 *  3. Access to data is through PUBLIC methods that we control.
 *     - There is NO getPhone(). The phone number can only be seen through
 *       getContactIfAllowed(), which returns it only when the donor gave consent.
 *     - There are NO public setters for every field. Only two controlled updates exist:
 *       updatePhone() (validated) and updateConsent().
 */
public class Donor {

    // ---------- Limits used by validation ----------
    private static final int MAX_NAME_LENGTH = 50;
    private static final int MAX_LOCATION_LENGTH = 40;

    // ---------- PRIVATE FIELDS (data hiding) ----------
    private final String name;          // final = cannot change after creation
    private final String bloodGroup;    // stored in standard form, e.g. "AB+"
    private final String city;
    private final String area;
    private String phone;               // not final, because updatePhone() may change it
    private boolean consentToContact;   // true only if the donor agreed to be contacted
    private final boolean sampleData;   // true for built-in fictional demo donors

    // ---------- CONSTRUCTORS ----------

    /** Creates a normal (user-registered) donor. */
    public Donor(String name, String bloodGroup, String city, String area,
                 String phone, boolean consentToContact) {
        this(name, bloodGroup, city, area, phone, consentToContact, false);
    }

    /** Full constructor. Validates everything; throws IllegalArgumentException if anything is invalid. */
    public Donor(String name, String bloodGroup, String city, String area,
                 String phone, boolean consentToContact, boolean sampleData) {

        // Run all the checks. The first problem found stops the object from being created.
        String problem = checkName(name);
        if (problem == null) problem = checkBloodGroup(bloodGroup);
        if (problem == null) problem = checkCity(city);
        if (problem == null) problem = checkArea(area);
        if (problem == null) problem = checkPhone(phone);
        if (problem != null) {
            throw new IllegalArgumentException(problem);
        }

        // Only clean, validated values are stored.
        this.name = cleanText(name);
        this.bloodGroup = BloodMatcher.normalizeBloodGroup(bloodGroup);
        this.city = cleanText(city);
        this.area = cleanText(area);
        this.phone = cleanPhone(phone);
        this.consentToContact = consentToContact;
        this.sampleData = sampleData;
    }

    // ---------- VALIDATION METHODS ----------
    // Each returns null if the value is fine, otherwise an error message.
    // They are public and static so Main can re-use them to re-ask the user
    // without duplicating the rules (the rules live in ONE place: here).

    public static String checkName(String name) {
        if (isBlank(name)) return "Name cannot be blank.";
        String cleaned = cleanText(name);
        if (cleaned.length() > MAX_NAME_LENGTH) return "Name is too long (maximum " + MAX_NAME_LENGTH + " characters).";
        if (!cleaned.matches("[A-Za-z][A-Za-z .'-]*"))
            return "Name may contain only letters, spaces, dots, apostrophes and hyphens.";
        return null;
    }

    public static String checkBloodGroup(String bloodGroup) {
        if (isBlank(bloodGroup)) return "Blood group cannot be blank.";
        if (!BloodMatcher.isSupportedBloodGroup(bloodGroup))
            return "Blood group must be one of: " + String.join(", ", BloodMatcher.getSupportedBloodGroups()) + ".";
        return null;
    }

    public static String checkCity(String city) {
        return checkLocationText(city, "City");
    }

    public static String checkArea(String area) {
        return checkLocationText(area, "Area");
    }

    public static String checkPhone(String phone) {
        if (isBlank(phone)) return "Contact number cannot be blank.";
        // Basic format check: 10 digits, starting with 6-9 (optional +91, spaces or hyphens allowed)
        if (!cleanPhone(phone).matches("[6-9][0-9]{9}"))
            return "Contact number must be a 10-digit mobile number starting with 6-9 (optional +91 allowed).";
        return null;
    }

    private static String checkLocationText(String value, String label) {
        if (isBlank(value)) return label + " cannot be blank.";
        String cleaned = cleanText(value);
        if (cleaned.length() > MAX_LOCATION_LENGTH) return label + " is too long (maximum " + MAX_LOCATION_LENGTH + " characters).";
        if (!cleaned.matches("[A-Za-z0-9][A-Za-z0-9 .'-]*"))
            return label + " may contain only letters, digits, spaces, dots, apostrophes and hyphens.";
        return null;
    }

    // ---------- CONTROLLED ACCESS (public getters) ----------

    public String getName()       { return name; }
    public String getBloodGroup() { return bloodGroup; }
    public String getCity()       { return city; }
    public String getArea()       { return area; }
    public boolean hasConsented() { return consentToContact; }
    public boolean isSampleData() { return sampleData; }

    /**
     * The ONLY way to read the phone number from outside.
     * If the donor has NOT consented, the number is never returned.
     */
    public String getContactIfAllowed() {
        if (consentToContact) {
            return phone;
        }
        return "Hidden (no consent)";
    }

    // ---------- CONTROLLED UPDATES (instead of public setters for everything) ----------

    /** Changes the phone number, but only if the new number is valid. */
    public void updatePhone(String newPhone) {
        String problem = checkPhone(newPhone);
        if (problem != null) {
            throw new IllegalArgumentException(problem);
        }
        this.phone = cleanPhone(newPhone);
    }

    /** Lets the donor give or withdraw consent. */
    public void updateConsent(boolean newConsent) {
        this.consentToContact = newConsent;
    }

    // ---------- LOCATION HELPERS ----------
    // Other classes ask the Donor "are you in this city?" instead of reading the field themselves.

    /** Case-insensitive, whitespace-tolerant city comparison. */
    public boolean isInCity(String otherCity) {
        return normalizeForCompare(city).equals(normalizeForCompare(otherCity));
    }

    /** Case-insensitive, whitespace-tolerant area comparison. */
    public boolean isInArea(String otherArea) {
        return normalizeForCompare(area).equals(normalizeForCompare(otherArea));
    }

    /** Duplicate rule: two registrations with the same phone number are treated as the same volunteer. */
    public boolean hasSamePhoneAs(Donor other) {
        return other != null && this.phone.equals(other.phone);
    }

    /** Safe text for display - never contains the phone number. */
    public String getPublicSummary() {
        return name + " (" + bloodGroup + "), " + area + ", " + city;
    }

    @Override
    public String toString() {
        return getPublicSummary();   // even printing the object cannot leak the phone number
    }

    // ---------- PRIVATE HELPER METHODS ----------

    private static boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }

    /** Trim and collapse repeated spaces: "  Anna   Nagar " -> "Anna Nagar". */
    private static String cleanText(String value) {
        return value.trim().replaceAll("\\s+", " ");
    }

    /** Remove spaces/hyphens and an optional +91 prefix. */
    private static String cleanPhone(String value) {
        String digits = value.trim().replace(" ", "").replace("-", "");
        if (digits.startsWith("+91")) {
            digits = digits.substring(3);
        }
        return digits;
    }

    /** Used for comparing locations: trimmed, single spaces, lower case. */
    private static String normalizeForCompare(String value) {
        if (value == null) return "";
        return value.trim().replaceAll("\\s+", " ").toLowerCase();
    }
}
