# BloodBridge - Emergency Blood Donor & Nearby Volunteer Matcher

A small Java console application (OOPS mini project, main concept: **encapsulation**).
Educational prototype only - it does NOT guarantee donor availability or medical eligibility.
Use fictional data only.

## Folder structure
```
BloodBridge/
  src/    Main.java  Donor.java  DonorManager.java  BloodMatcher.java  MatchResult.java
  tests/  TestRunner.java  inputs/ (sample menu inputs)  outputs/ (recorded outputs)
  README.md
```

## 1. Install Java (macOS)
1. Install a JDK, version 11 or newer (Temurin 21 is a good choice): https://adoptium.net  
   (or with Homebrew: `brew install --cask temurin`)
2. Check in Terminal:  `java -version`  and  `javac -version`  (both must work)
3. Install VS Code and the extension "Extension Pack for Java".

## 2. Compile and run (Terminal, inside the BloodBridge folder)
```
mkdir -p out
javac -d out src/*.java
java -cp out Main
```
Start without sample volunteers (to test the empty list / no-match cases):
```
java -cp out Main --no-sample
```

## 3. Run the automated tests
```
javac -cp out -d out tests/TestRunner.java
java -cp out TestRunner
```
Expected last line: `Result: 35 passed, 0 failed.`

## 4. Run a scripted session (types the inputs for you)
```
java -cp out Main < tests/inputs/M1_full_demo.txt
```

## 5. In VS Code
Open the BloodBridge folder, open `src/Main.java` and click "Run" above `main`. Or use the terminal commands above.
