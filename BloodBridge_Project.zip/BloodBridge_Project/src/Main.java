import java.util.List;
import java.util.Scanner;

/**
 * Main.java
 * ---------
 * Starts the program, shows the menu, reads the user's input and displays results.
 * It contains NO blood-compatibility rules and NO validation rules:
 *   - validation lives in Donor
 *   - the list of donors lives in DonorManager
 *   - matching lives in BloodMatcher
 */
public class Main {

    private static final Scanner scanner = new Scanner(System.in);
    private static final DonorManager manager = new DonorManager();
    private static final BloodMatcher matcher = new BloodMatcher();

    public static void main(String[] args) {
        // Load fictional demo volunteers, unless the program was started with: java Main --no-sample
        boolean skipSamples = args.length > 0 && args[0].equals("--no-sample");
        if (!skipSamples) {
            manager.loadSampleData();
        }

        boolean running = true;
        while (running) {
            printMenu();
            String line = readLine();
            if (line == null) {                       // input ended (e.g. file input) -> stop safely
                System.out.println("\n(No more input.)");
                break;
            }

            int choice = parseMenuChoice(line);
            switch (choice) {
                case 1:  registerVolunteer();   break;
                case 2:  viewVolunteers();      break;
                case 3:  searchForDonors();     break;
                case 4:  showProjectInfo();     break;
                case 5:  running = false;       break;
                default:
                    System.out.println("\nInvalid choice. Please enter a number from 1 to 5.");
            }
        }
        System.out.println("\nThank you for using BloodBridge. Stay safe, and please contact a hospital or blood bank in an emergency!");
    }

    // ================= MENU =================

    private static void printMenu() {
        System.out.println();
        System.out.println("========================================");
        System.out.println("       BLOODBRIDGE");
        System.out.println(" Emergency Blood Donor Matcher");
        System.out.println("========================================");
        System.out.println();
        System.out.println("1. Register a Volunteer");
        System.out.println("2. View Registered Volunteers");
        System.out.println("3. Search for Compatible Donors Nearby");
        System.out.println("4. View Project Information");
        System.out.println("5. Exit");
        System.out.println();
        System.out.print("Enter your choice: ");
    }

    /** Turns text into a number; returns -1 if it is not a number (so no crash on "abc"). */
    private static int parseMenuChoice(String text) {
        try {
            return Integer.parseInt(text.trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    // ================= OPTION 1: REGISTER =================

    private static void registerVolunteer() {
        System.out.println("\n--- Register a Volunteer ---");
        System.out.println("(Type 'cancel' at any question to go back to the menu.)");
        System.out.println("Use only fictional details when testing.\n");

        String name = readValidated("Full name: ", "name");
        if (name == null) { printCancelled(); return; }

        String bloodGroup = readValidated("Blood group (A+, A-, B+, B-, AB+, AB-, O+, O-): ", "bloodgroup");
        if (bloodGroup == null) { printCancelled(); return; }

        String city = readValidated("City: ", "city");
        if (city == null) { printCancelled(); return; }

        String area = readValidated("Area / locality: ", "area");
        if (area == null) { printCancelled(); return; }

        String phone = readValidated("Contact number (10 digits): ", "phone");
        if (phone == null) { printCancelled(); return; }

        Boolean consent = readYesNo("May people seeking blood contact you? (yes/no): ");
        if (consent == null) { printCancelled(); return; }

        try {
            // The Donor constructor validates everything once more - encapsulation in action.
            Donor donor = new Donor(name, bloodGroup, city, area, phone, consent);
            if (manager.registerDonor(donor)) {
                System.out.println("\nRegistration successful!");
                System.out.println("  Name       : " + donor.getName());
                System.out.println("  Blood group: " + donor.getBloodGroup());
                System.out.println("  Location   : " + donor.getArea() + ", " + donor.getCity());
                System.out.println("  Contactable: " + (donor.hasConsented() ? "Yes" : "No (your number will stay hidden)"));
            } else {
                System.out.println("\nA volunteer with this contact number is already registered. Duplicate not added.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("\nRegistration failed: " + e.getMessage());
        }
    }

    // ================= OPTION 2: VIEW =================

    private static void viewVolunteers() {
        System.out.println("\n--- Registered Volunteers ---");
        if (manager.isEmpty()) {
            System.out.println("No volunteers are registered yet.");
            return;
        }
        System.out.println("Total: " + manager.getTotalCount()
                + "  (Sample/demo: " + manager.getSampleCount()
                + ", Registered by you: " + manager.getRegisteredCount() + ")\n");

        System.out.printf("%-3s %-22s %-6s %-12s %-14s %-16s %s%n",
                "No", "Name", "Blood", "City", "Area", "Contact status", "Type");
        System.out.println("-----------------------------------------------------------------------------------");

        List<Donor> all = manager.getAllDonors();
        int number = 1;
        for (Donor d : all) {
            // Phone numbers are NEVER printed here, only whether the donor can be contacted.
            String contactStatus = d.hasConsented() ? "Consented" : "Not shared";
            String type = d.isSampleData() ? "SAMPLE" : "REGISTERED";
            System.out.printf("%-3d %-22s %-6s %-12s %-14s %-16s %s%n",
                    number, d.getName(), d.getBloodGroup(), d.getCity(), d.getArea(), contactStatus, type);
            number++;
        }
        System.out.println("\nPhone numbers are shown only in search results, and only for volunteers who consented.");
    }

    // ================= OPTION 3: SEARCH =================

    private static void searchForDonors() {
        System.out.println("\n--- Search for Compatible Donors ---");
        System.out.println("(Type 'cancel' at any question to go back to the menu.)\n");

        if (manager.isEmpty()) {
            System.out.println("There are no registered volunteers to search.");
            return;
        }

        String groupText = readValidated("Required blood group (A+, A-, B+, B-, AB+, AB-, O+, O-): ", "bloodgroup");
        if (groupText == null) { printCancelled(); return; }
        String city = readValidated("Your city: ", "city");
        if (city == null) { printCancelled(); return; }
        String area = readValidated("Your area / locality: ", "area");
        if (area == null) { printCancelled(); return; }

        String recipientGroup = BloodMatcher.normalizeBloodGroup(groupText);
        List<Donor> allDonors = manager.getAllDonors();
        List<MatchResult> results = matcher.findMatches(allDonors, recipientGroup, city, area);

        System.out.println("\nRecipient blood group : " + recipientGroup);
        System.out.println("Compatible donor groups (red blood cells): "
                + String.join(", ", BloodMatcher.getCompatibleDonorGroups(recipientGroup)));
        System.out.println("Searching near       : " + area.trim() + ", " + city.trim()
                + "  (matched by NAME, not GPS distance)");

        if (results.isEmpty()) {
            System.out.println("\nNo potential matches found. No consenting volunteer with a compatible blood group is registered.");
            System.out.println("Please contact a hospital or blood bank directly.");
        } else {
            System.out.println("\nPotential matches found: " + results.size());
            int lastPriority = 0;
            int number = 1;
            for (MatchResult result : results) {
                if (result.getPriority() != lastPriority) {     // print a heading when the group changes
                    System.out.println("\n=== " + result.getPriorityLabel() + " ===");
                    lastPriority = result.getPriority();
                }
                Donor d = result.getDonor();
                String groupNote = result.isExactGroupMatch() ? "same group" : "compatible group";
                System.out.println(number + ". " + d.getName() + "  |  " + d.getBloodGroup() + " (" + groupNote + ")"
                        + "  |  " + d.getArea() + ", " + d.getCity()
                        + (d.isSampleData() ? "  [SAMPLE]" : ""));
                // getContactIfAllowed() only returns a number because every result has consented.
                System.out.println("   Contact: " + d.getContactIfAllowed());
                number++;
            }
        }

        int hidden = matcher.countCompatibleWithoutConsent(allDonors, recipientGroup);
        if (hidden > 0) {
            System.out.println("\nNote: " + hidden + " compatible volunteer(s) are not shown because they have not consented to be contacted.");
        }

        System.out.println("\nIMPORTANT: A match does NOT guarantee that a donor is available or medically eligible.");
        System.out.println("Always confirm with a hospital or blood bank. BloodBridge is an educational prototype.");
    }

    // ================= OPTION 4: INFO =================

    private static void showProjectInfo() {
        System.out.println("\n--- About BloodBridge ---");
        System.out.println("Purpose : Helps a person seeking blood find volunteers with potentially compatible blood groups");
        System.out.println("          in the same area, same city or elsewhere, using only volunteers who consented to contact.");
        System.out.println("OOPS concept: ENCAPSULATION - the Donor class keeps its data private, validates it in the");
        System.out.println("          constructor, and exposes it only through controlled public methods.");
        System.out.println("Limitations:");
        System.out.println("  - Data is stored in memory only; it disappears when the program closes.");
        System.out.println("  - Location matching compares city/area names. It is NOT GPS and shows no distances.");
        System.out.println("  - Uses standard red-cell compatibility rules for education only.");
        System.out.println("  - A match does not guarantee availability or medical eligibility.");
        System.out.println("  - Not a replacement for hospitals, blood banks or emergency services.");
        System.out.println("  - Use fictional data only.");
    }

    // ================= INPUT HELPERS =================

    /** Reads one line; returns null if there is no more input. */
    private static String readLine() {
        if (!scanner.hasNextLine()) return null;
        return scanner.nextLine();
    }

    /**
     * Keeps asking until the answer is valid. The checking itself is done by the Donor class.
     * Returns null if the user types "cancel" (or the input ends).
     */
    private static String readValidated(String prompt, String fieldType) {
        while (true) {
            System.out.print(prompt);
            String line = readLine();
            if (line == null || line.trim().equalsIgnoreCase("cancel")) return null;

            String problem;
            switch (fieldType) {
                case "name":       problem = Donor.checkName(line);       break;
                case "bloodgroup": problem = Donor.checkBloodGroup(line); break;
                case "city":       problem = Donor.checkCity(line);       break;
                case "area":       problem = Donor.checkArea(line);       break;
                default:           problem = Donor.checkPhone(line);      break;
            }
            if (problem == null) return line;
            System.out.println("  Invalid input: " + problem);
        }
    }

    /** Asks a yes/no question. Returns TRUE/FALSE, or null on cancel. */
    private static Boolean readYesNo(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = readLine();
            if (line == null || line.trim().equalsIgnoreCase("cancel")) return null;

            String answer = line.trim().toLowerCase();
            if (answer.equals("yes") || answer.equals("y")) return Boolean.TRUE;
            if (answer.equals("no")  || answer.equals("n")) return Boolean.FALSE;
            System.out.println("  Invalid input: please answer yes or no.");
        }
    }

    private static void printCancelled() {
        System.out.println("\nCancelled. Returning to the main menu.");
    }
}
