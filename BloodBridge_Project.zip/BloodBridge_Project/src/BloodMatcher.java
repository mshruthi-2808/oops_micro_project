import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * BloodMatcher.java
 * -----------------
 * Contains ALL the matching logic, kept separate from Main (menu / input):
 *   - red blood cell donor-to-recipient compatibility rules
 *   - searching the donors, filtering by consent, and ranking by location
 *
 * EDUCATIONAL PROTOTYPE ONLY: real transfusion decisions need blood-bank testing.
 */
public class BloodMatcher {

    // The eight supported blood groups.
    private static final List<String> SUPPORTED_GROUPS =
            List.of("A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-");

    // KEY = RECIPIENT's group, VALUE = groups of donors whose red cells may be compatible.
    // (Direction: "who can GIVE to this recipient".)
    private static final Map<String, List<String>> DONOR_GROUPS_FOR_RECIPIENT = Map.of(
            "O-",  List.of("O-"),
            "O+",  List.of("O-", "O+"),
            "A-",  List.of("O-", "A-"),
            "A+",  List.of("O-", "O+", "A-", "A+"),
            "B-",  List.of("O-", "B-"),
            "B+",  List.of("O-", "O+", "B-", "B+"),
            "AB-", List.of("O-", "A-", "B-", "AB-"),
            "AB+", List.of("A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-")
    );

    // ---------- Blood-group helpers (static: they need no object state) ----------

    public static List<String> getSupportedBloodGroups() {
        return SUPPORTED_GROUPS;   // List.of(...) is unmodifiable, so this is safe to share
    }

    /** "  ab+ " -> "AB+". Returns "" for null. */
    public static String normalizeBloodGroup(String group) {
        if (group == null) return "";
        return group.trim().toUpperCase().replace(" ", "");
    }

    public static boolean isSupportedBloodGroup(String group) {
        return SUPPORTED_GROUPS.contains(normalizeBloodGroup(group));
    }

    /** Which donor groups can give red cells to this recipient group? */
    public static List<String> getCompatibleDonorGroups(String recipientGroup) {
        String recipient = normalizeBloodGroup(recipientGroup);
        if (!SUPPORTED_GROUPS.contains(recipient)) {
            throw new IllegalArgumentException("Unsupported blood group: " + recipientGroup);
        }
        return DONOR_GROUPS_FOR_RECIPIENT.get(recipient);
    }

    /** Can a donor with donorGroup give red cells to a recipient with recipientGroup? */
    public static boolean canDonateTo(String donorGroup, String recipientGroup) {
        if (!isSupportedBloodGroup(donorGroup) || !isSupportedBloodGroup(recipientGroup)) {
            return false;
        }
        return getCompatibleDonorGroups(recipientGroup).contains(normalizeBloodGroup(donorGroup));
    }

    // ---------- Searching ----------

    /**
     * Finds donors who (1) have a compatible blood group and (2) have consented to contact,
     * then ranks them: same area+city, then same city, then other cities.
     * NOTE: this compares city/area NAMES only. It is NOT a GPS distance.
     */
    public List<MatchResult> findMatches(List<Donor> donors, String recipientGroup,
                                         String seekerCity, String seekerArea) {
        String recipient = normalizeBloodGroup(recipientGroup);
        List<MatchResult> results = new ArrayList<>();

        for (Donor donor : donors) {
            // Step 1: blood group must be compatible in the donor -> recipient direction
            if (!canDonateTo(donor.getBloodGroup(), recipient)) continue;

            // Step 2: skip volunteers who did not consent to be contacted
            if (!donor.hasConsented()) continue;

            // Step 3: decide the location priority
            int priority;
            if (donor.isInCity(seekerCity) && donor.isInArea(seekerArea)) {
                priority = MatchResult.SAME_AREA_AND_CITY;
            } else if (donor.isInCity(seekerCity)) {
                priority = MatchResult.SAME_CITY_OTHER_AREA;
            } else {
                priority = MatchResult.OTHER_CITY;
            }

            boolean exact = donor.getBloodGroup().equals(recipient);
            results.add(new MatchResult(donor, priority, exact));
        }

        Collections.sort(results);   // uses MatchResult.compareTo()
        return results;
    }

    /** How many compatible volunteers were left out only because they have not consented? */
    public int countCompatibleWithoutConsent(List<Donor> donors, String recipientGroup) {
        int count = 0;
        for (Donor donor : donors) {
            if (canDonateTo(donor.getBloodGroup(), recipientGroup) && !donor.hasConsented()) {
                count++;
            }
        }
        return count;
    }
}
