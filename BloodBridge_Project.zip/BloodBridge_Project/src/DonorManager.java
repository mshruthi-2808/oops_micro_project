import java.util.ArrayList;
import java.util.List;

/**
 * DonorManager.java
 * -----------------
 * Owns the list of donors (an ArrayList kept in memory).
 * The list itself is PRIVATE: other classes can only use the public methods below.
 * getAllDonors() hands out a COPY of the list, so outside code cannot add or remove
 * donors behind the manager's back.
 */
public class DonorManager {

    private final ArrayList<Donor> donors = new ArrayList<>();

    /** Adds a donor. Returns false (and does not add) if the phone number is already registered. */
    public boolean registerDonor(Donor newDonor) {
        if (newDonor == null) return false;
        for (Donor existing : donors) {
            if (existing.hasSamePhoneAs(newDonor)) {
                return false;   // duplicate
            }
        }
        donors.add(newDonor);
        return true;
    }

    /** Returns a COPY of the list (defensive copy). */
    public List<Donor> getAllDonors() {
        return new ArrayList<>(donors);
    }

    public int getTotalCount() { return donors.size(); }
    public boolean isEmpty()   { return donors.isEmpty(); }

    public int getSampleCount() {
        int count = 0;
        for (Donor d : donors) {
            if (d.isSampleData()) count++;
        }
        return count;
    }

    public int getRegisteredCount() {
        return donors.size() - getSampleCount();
    }

    /**
     * Loads FICTIONAL demo volunteers so searching can be tested immediately.
     * All names and numbers are made up. Edit the city/area names to suit your demo.
     */
    public void loadSampleData() {
        registerDonor(new Donor("Aarav Sharma", "O-",  "Bengaluru", "Indiranagar",  "9000000001", true,  true));
        registerDonor(new Donor("Meera Nair",   "A+",  "Bengaluru", "Indiranagar",  "9000000002", true,  true));
        registerDonor(new Donor("Rohan Verma",  "B+",  "Bengaluru", "Koramangala",  "9000000003", true,  true));
        registerDonor(new Donor("Sneha Iyer",   "O+",  "Bengaluru", "Indiranagar",  "9000000004", false, true)); // NO consent
        registerDonor(new Donor("Karthik Rao",  "AB+", "Mysuru",    "Vijayanagar",  "9000000005", true,  true));
        registerDonor(new Donor("Divya Menon",  "A-",  "Bengaluru", "Jayanagar",    "9000000006", true,  true));
        registerDonor(new Donor("Imran Khan",   "O+",  "Mysuru",    "Kuvempunagar", "9000000007", true,  true));
    }
}
