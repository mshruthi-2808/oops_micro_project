/**
 * MatchResult.java
 * ----------------
 * A small helper class: ONE search result = a Donor + how good the match is.
 * Its fields are private too (encapsulation), and it knows how to sort itself
 * (Comparable), so the matcher can simply call Collections.sort(results).
 */
public class MatchResult implements Comparable<MatchResult> {

    public static final int SAME_AREA_AND_CITY = 1;
    public static final int SAME_CITY_OTHER_AREA = 2;
    public static final int OTHER_CITY = 3;

    private final Donor donor;
    private final int priority;            // 1 = best, 3 = widest
    private final boolean exactGroupMatch; // true if donor's group is identical to the requested group

    public MatchResult(Donor donor, int priority, boolean exactGroupMatch) {
        this.donor = donor;
        this.priority = priority;
        this.exactGroupMatch = exactGroupMatch;
    }

    public Donor getDonor()              { return donor; }
    public int getPriority()             { return priority; }
    public boolean isExactGroupMatch()   { return exactGroupMatch; }

    public String getPriorityLabel() {
        if (priority == SAME_AREA_AND_CITY)   return "PRIORITY 1 - Same area and same city";
        if (priority == SAME_CITY_OTHER_AREA) return "PRIORITY 2 - Same city, different area";
        return "PRIORITY 3 - Other cities (wider-area results)";
    }

    /**
     * Sorting rule (easy to explain):
     *   1) lower priority number first (same area -> same city -> other city)
     *   2) within the same priority, an identical blood group comes before a merely compatible one
     *   3) then alphabetical by name, so the order is always consistent
     */
    @Override
    public int compareTo(MatchResult other) {
        if (this.priority != other.priority) {
            return Integer.compare(this.priority, other.priority);
        }
        if (this.exactGroupMatch != other.exactGroupMatch) {
            return this.exactGroupMatch ? -1 : 1;
        }
        return this.donor.getName().compareToIgnoreCase(other.donor.getName());
    }
}
